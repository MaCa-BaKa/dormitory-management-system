<template>
  <div>
    <svg-icon icon-class="question" @click="goto" />
  </div>
</template>

<script>
export default {
  name: 'RuoYiDoc',
  data() {
    return {
      url: 'https://ryxy.zjgsu.edu.cn/main.htm'
    }
  },
  methods: {
    goto() {
      window.open(this.url)
    }
  }
}
</script>
