import request from '@/utils/request'

// 查询人物信息列表
export function listKeyman(query) {
  return request({
    url: '/system/keyman/list',
    method: 'get',
    params: query
  })
}

// 查询人物信息详细
export function getKeyman(pId) {
  return request({
    url: '/system/keyman/' + pId,
    method: 'get'
  })
}

// 新增人物信息
export function addKeyman(data) {
  return request({
    url: '/system/keyman',
    method: 'post',
    data: data
  })
}

// 修改人物信息
export function updateKeyman(data) {
  return request({
    url: '/system/keyman',
    method: 'put',
    data: data
  })
}

// 删除人物信息
export function delKeyman(pId) {
  return request({
    url: '/system/keyman/' + pId,
    method: 'delete'
  })
}
